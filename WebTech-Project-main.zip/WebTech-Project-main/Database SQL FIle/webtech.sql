-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 22, 2022 at 04:05 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webtech`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(5) NOT NULL,
  `username` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `password` varchar(200) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `email` varchar(50) NOT NULL,
  `hiredate` date NOT NULL,
  `resignDate` date DEFAULT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `name`, `password`, `phone`, `email`, `hiredate`, `resignDate`, `address`) VALUES
(17, 'admin', 'admin', '$2y$10$JbHYE0LsE0gWtnQXM3Xx5O9IwfgOkAkONR6SaV5/XCxYvGmnp8gDu', '00000000000', 'admin@admin.com', '2020-09-22', NULL, 'admin'),
(23, 'admin123', 'iqbal', '$2y$10$c9ZF3eyu9rVGoBrBsQ5g8.MtnfKp2cG7Hp9N8rYmlyWf2NDOINXOa', '01728617202', 'iqbal123@gmail.com', '2022-04-03', NULL, 'Nikunja'),
(24, 'admin1234', 'sdadadadasda', '$2y$10$naiHydJayFL7bMAL9oA9BuWPYRncNJ3eIAXyAIbtGoanirJsAOt/O', '01234567894', 'admin123@gmail.com', '2022-04-03', NULL, 'asdasdasdasda'),
(25, 'tahsin1234', 'Tahsin', '$2y$10$z66KG4hbpu94kkdDSxGEGu96DGnejFaH2U.j/VEVJKmaPMdeyxdy.', '01788671327', 'tahsinpurba@gmail.com', '2022-04-03', NULL, 'Basundhara,Dhaka'),
(26, 'takiul1234', 'Takiul', '$2y$10$R5Z3WlXR9iijfTcLAS7Vwey3GsOQbAazY5Sw3JMMgdf80YVRV6rCa', '01768877155', 'takiul@gmail.com', '2022-04-04', NULL, 'Basundhara,Dhaka');

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` int(5) NOT NULL,
  `dateTime` datetime NOT NULL,
  `appointment_query` text NOT NULL,
  `patientId` int(5) NOT NULL,
  `doctorId` int(5) NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`id`, `dateTime`, `appointment_query`, `patientId`, `doctorId`, `status`) VALUES
(27, '2020-09-23 16:38:00', 'I am sick', 32, 14, 5),
(28, '2020-09-23 16:38:00', 'Very Vey Sick.', 31, 12, 1),
(29, '2022-04-19 14:00:00', 'Eye problem .', 37, 18, 0),
(30, '2022-05-04 15:00:00', 'Heart problem.', 38, 16, 0),
(31, '2022-04-19 16:00:00', ' i have high fever last few days', 38, 14, 0);

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `id` int(5) NOT NULL,
  `username` varchar(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `password` varchar(200) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `Address` text NOT NULL,
  `hireDate` date NOT NULL,
  `resignDate` date DEFAULT NULL,
  `visitingHour` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `Speciality` varchar(50) NOT NULL,
  `Details` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`id`, `username`, `Name`, `password`, `phone`, `Address`, `hireDate`, `resignDate`, `visitingHour`, `email`, `Speciality`, `Details`) VALUES
(14, 'reza', 'Dr. Abu Reza Mohammad Nooruzzaman', '$2y$10$32boA/Ny9X3CX4VI4HoOIuz6ciNuHKtqK8Xs6eEb8EvvRM0yzv5R.', '01981423334', '18/F West Panthapath, Dhaka - 1205, Bangladesh.', '2020-09-22', NULL, '16:00-18:00', 'drnzaman@squarehospital.com', 'Internal Medicine', 'MBBS, FCPS'),
(15, 'abu123', 'Md abu Yousuf', '$2y$10$SP4P5GrEGZR1vRqVr4HtV.h9hVB7AjGkNdjDlmpVDki1aUGLC32T2', '01512457896', 'dahaka,kuril', '2020-03-01', NULL, '10:05-17:00', 'abu@gmail.com', ' sergery', 'mmbs dhaka medical, fcps bsrmu,'),
(16, 'iqbal000', ' Iqbal Hossain', '$2y$10$VbCXGfxcZxTzGYNY5f2S5u9pm2VDDuyFBUuZ/0ZLmpaTA/p8C8PJG', '01628617204', 'Dhaka', '2022-04-04', NULL, '10:00-17:00', 'iqbal000@gmail.com', 'Heart ', 'xxxxxxxxx'),
(17, 'tahsin000', ' Tahsin', '$2y$10$AfDGmF1rx9epIiISrzdyFuAU1vuuFBSlG6klts4mZC9rbsM5bGsr2', '01811111111', 'Dhaka', '2022-04-04', NULL, '17:00-22:00', 'tahsin000@gmail.com', 'Dentist', 'xxxxxxx'),
(18, 'takiul000', 'Takiul', '$2y$10$b6ziIvwtWHjLCC3EyYnEvOW8dAgCOyjRCtQYNYiR4ofNzQ/CxYcam', '01344444440', 'Dhaka', '2021-04-10', NULL, '12:00-20:00', 'takiul000@gmail.com', 'Eye', 'xxxxxxxxxx');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `id` int(5) NOT NULL,
  `username` varchar(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `password` varchar(200) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `dateOfBirth` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`id`, `username`, `Name`, `password`, `phone`, `email`, `address`, `dateOfBirth`) VALUES
(31, 'karim', 'Abdul Karim', '$2y$10$i9JaaP.jtY.SBIJoSFTjhOIIjd2tWg6.MB06dwYykjTOJBpaFIH2K', '01457845691', 'sadsa@gmail.com', 'Dhaka', '1997-09-02'),
(32, 'fardit', 'Fardit Ahmed Shawkot', '$2y$10$itS6.e.MPe2E8Rlt4xn2fe9RjU1kI24TQxnB4fyRee9jUwEhr6uWq', '01234567847', 'fardit@gmail.com', 'Banasree,Dhaka', '1998-05-05'),
(33, 'abcd', 'abc', '$2y$10$cgKOBJFOi/l9.yZaF57q9udFX5YDxnNWsVIPRESz7fwksAuPPBBu2', '01628617203', 'abc@gmail.com', 'aaaaa', '1990-04-11'),
(34, 'iqbal100', 'Iqbal Hossain', '$2y$10$MG1UxLJXbFgCeTFVZW0uWuaYbFlgJmo9MFng.kZlxtdQMHaag7DFm', '01628617202', 'iqbal@gmail.com', 'dhaka,dhaka', '1999-03-07'),
(35, 'abul123', 'abul', '$2y$10$rAv20JNSlNjLP6SxgCOUNuIes1WcOIH1FHJU0FrRac43DACZtRE/O', '01301236455', 'abul@gmail.com', 'dhaka,dhaka', '2002-03-01'),
(36, 'rayhan', 'rayhan', '$2y$10$tKOAEVHkJhhkRIgiqFNCf./rbv3tyRpU1.36q7MuKAEBVXztkbDd6', '01234567897', 'rayhan@gmail.com', 'abcd', '2002-03-07'),
(37, 'iqbal222', 'Iqbal Hossain', '$2y$10$JsPBBWfwDsfYgEeFPLbTNeL1MELuXyO7r4jQe6XvgXNqa/zJ2nnaa', '01245787894', 'iqbal222@gmail.com', 'Dhaka', '2006-04-11'),
(38, 'tahsin222', 'Tahsin', '$2y$10$/DN90dCs4S/A6K/ncSpfZumsDr/gzIwc1zaAaSE9zPzQQHns1wsoq', '01470258036', 'tahsin222@gmail.com', 'dhaka', '1980-04-10');

-- --------------------------------------------------------

--
-- Table structure for table `query`
--

CREATE TABLE `query` (
  `id` int(5) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Query` text NOT NULL,
  `email` varchar(50) NOT NULL,
  `dateTime` datetime NOT NULL,
  `status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `query`
--

INSERT INTO `query` (`id`, `Name`, `Query`, `email`, `dateTime`, `status`) VALUES
(20, 'aaaaaaa', 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx xxxxxxxxxxxxxxxxxx  xxxxxxxxxxxxxxx', 'aaaaaaa@gmail.com', '2022-04-17 08:13:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `support`
--

CREATE TABLE `support` (
  `id` int(5) NOT NULL,
  `username` varchar(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `password` varchar(200) NOT NULL,
  `address` text NOT NULL,
  `phone` varchar(15) NOT NULL,
  `hiredate` date NOT NULL,
  `resignDate` date DEFAULT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `support`
--

INSERT INTO `support` (`id`, `username`, `Name`, `password`, `address`, `phone`, `hiredate`, `resignDate`, `email`) VALUES
(5, 'support1234', 'Support', '$2y$10$Lab64eHOm2u4MOXRXZRH5u6x9sPJAWNIyUcOqS478G9DW9KkDZGMe', 'xxxxxx', '01478963258', '2022-04-04', NULL, 'support1234@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `query`
--
ALTER TABLE `query`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `support`
--
ALTER TABLE `support`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `query`
--
ALTER TABLE `query`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `support`
--
ALTER TABLE `support`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
