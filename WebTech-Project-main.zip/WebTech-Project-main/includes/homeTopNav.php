<div id="topNav">
		<a href="index.php"><img class="navLogo" src="skins/logo.png"></a>
		<div class="cont_navTab">
			<a class="navTab" href="doclist.php">Doctor's List</a>
			<a class="navTab" href="patient_register.php">Register as Patient</a>
			<a class="navTab" href="index.php#query">Post Query</a>
			<a class="navTab login_btn" href="login.php">Login</a>
		</div>
	</div>