<div class="leftNav">
		<a href="index.php"><img class="navLogo" src="skins/logo.png"></a>

		<div class="cont_tab">
			<a class="tab" href="doc_patients.php">My Patients</a>
			<a class="tab" href="doc_appoinments.php">Appointments</a>
			<a class="tab" href="doc_profile.php">My Profile</a>

			<form method="POST"><button class="tab logout" type="submit" name="logOut">Logout</button></form>
		</div>
	</div>